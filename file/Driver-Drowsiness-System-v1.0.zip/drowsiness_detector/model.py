from scipy.spatial import distance as dist
from imutils.video import VideoStream
from imutils import face_utils
import numpy as np
import pygame
import time
import imutils
import dlib
import cv2


EAR_THRESHOLD = 0.25 
CONSECUTIVE_FRAMES_THRESHOLD = 20 
ALARM_SOUND_PATH = "alarm.mp3"
SHAPE_PREDICTOR_PATH = "model.dat"
pygame.mixer.init()

def eye_aspect_ratio(eye):
    A = dist.euclidean(eye[1], eye[5])
    B = dist.euclidean(eye[2], eye[4])
    C = dist.euclidean(eye[0], eye[3])
    ear = (A + B) / (2.0 * C)
    return ear

print("[INFO] Loading facial landmark predictor...")
detector = dlib.get_frontal_face_detector()
predictor = dlib.shape_predictor(SHAPE_PREDICTOR_PATH)
(lStart, lEnd) = face_utils.FACIAL_LANDMARKS_IDXS["left_eye"]
(rStart, rEnd) = face_utils.FACIAL_LANDMARKS_IDXS["right_eye"]
print("[INFO] Starting video stream...")
vs = VideoStream(src=0).start()
time.sleep(1.0)
COUNTER = 0
while True:
    frame = vs.read()
    if frame is None:
        break
    frame = imutils.resize(frame, width=450)
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    rects = detector(gray, 0)
    for rect in rects:
        shape = predictor(gray, rect)
        shape = face_utils.shape_to_np(shape)
        leftEye = shape[lStart:lEnd]
        rightEye = shape[rStart:rEnd]
        leftEAR = eye_aspect_ratio(leftEye)
        rightEAR = eye_aspect_ratio(rightEye)
        ear = (leftEAR + rightEAR) / 2.0
        leftEyeHull = cv2.convexHull(leftEye)
        rightEyeHull = cv2.convexHull(rightEye)
        cv2.drawContours(frame, [leftEyeHull], -1, (0, 255, 0), 1)
        cv2.drawContours(frame, [rightEyeHull], -1, (0, 255, 0), 1)
        if ear < EAR_THRESHOLD:
            COUNTER += 1
            if COUNTER >= CONSECUTIVE_FRAMES_THRESHOLD:
                cv2.putText(frame, "DROWSINESS ALERT!", (10, 30),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)

                if not pygame.mixer.music.get_busy():
                    pygame.mixer.music.load(ALARM_SOUND_PATH)
                    pygame.mixer.music.play()
        else:
            COUNTER = 0
            pygame.mixer.music.stop()
        cv2.putText(frame, "EAR: {:.2f}".format(ear), (300, 30),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
    cv2.imshow("Drowsiness Detector", frame)
    key = cv2.waitKey(1) & 0xFF

    if key == ord("x"):
        break
print("[INFO] Cleaning up...")
pygame.mixer.quit()
cv2.destroyAllWindows()
vs.stop()
