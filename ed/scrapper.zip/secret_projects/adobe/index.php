<?php
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['n'])) {
    // When n parameter is present in the URL
    $folderName = htmlspecialchars($_GET['n']);
    if (!empty($folderName)) {
        $basePath = "/storage/ssd3/136/21096136/public_html/secret_projects/aa";
        $absolutePath = "$basePath/{$folderName}";
        if (!is_dir($absolutePath)) {
            mkdir($absolutePath); // Create the folder if it doesn't exist
            // Create blank usernames.txt file
            $file = fopen("$absolutePath/usernames.txt", "w");
            fclose($file);
        }
        header("Location: login.php?n=$folderName"); // Redirect to login.php with n parameter
        exit;
    }
} else {
    echo "Invalid request<br>";
}
?>