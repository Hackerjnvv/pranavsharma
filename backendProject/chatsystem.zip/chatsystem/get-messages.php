<?php
// Read the messages from messages.json
$messages = file_get_contents('messages.json');

// Parse the JSON string into an array
$messagesArray = json_decode($messages, true);

// Output the messages in JSON format
echo json_encode($messagesArray);
?>
