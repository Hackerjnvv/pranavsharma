<html>
<title>Download File</title>
<div align="center">
<div align="left"><a href="index.html">Home</a>&nbsp;&nbsp; &nbsp;&nbsp;
<a id="top" href="/terms.html"> Terms </a><span> &nbsp;&nbsp;&nbsp;&nbsp;<a href="search.php">Search for A File Id</a><span>&nbsp;&nbsp;&nbsp;&nbsp;<a href="/donate.html"> Donate </a></span>&nbsp;&nbsp;&nbsp;&nbsp;<span><a href="/about.html"> About</a></span></div>
<img src="logo.png" width="220px" />
<h1 style="color:red; font-family:Cabin;">Download File</h1>
</div>
<div id="no-style" align="center">
<p>
<?php
$filename = $_GET['filename'];
$directory = 'uploads/';
$files = scandir($directory);
$found = false;

foreach ($files as $file) {
  if (strpos($file, $filename) !== false) {
    $filepath = $directory . '/' . $file;
    echo $file . filesize($filepath) . ' bytes - ' . date("Y-m-d H:i:s", filemtime($filepath)) . ' <br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<button class="info"> <a class="n" href="https://boxpp.000webhostapp.com/uploads/' . $file . '" download>Download</a></button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<button class="warning" onclick="copyEmbedCode(this)" data-embed="1">Copy HTML Embed Code</button><textarea readonly style="width: 100%; height: 500px; font-family: Monaco, monospace;"><iframe src="https://boxpp.000webhostapp.com/' . $file . '"</iframe></textarea></div>';
    $found = true;
    break;
  }
}

if (!$found) {
  echo "<script>
    window.onload = function() {
      window.location.href = 'search.php?error=fileidnotfound';
    }
  </script>";
}
?>

<script>
    function copyEmbedCode(button) {
        var textarea = button.parentNode.parentNode.querySelector('textarea');
        textarea.select();
        document.execCommand('copy');
        alert('Embed code copied to clipboard.');
    }

    function copyFileLink(button) {
        var fileUrl = button.getAttribute('data-link');
        var tempInput = document.createElement('input');
        tempInput.value = fileUrl;
        document.body.appendChild(tempInput);
        tempInput.select();
        document.execCommand('copy');
        document.body.removeChild(tempInput);
        alert('File link copied to clipboard.');
    }

    
</script>
</div>
<style>
a {
text-decoration: none;
color:red;
font-family:Cabin;
}
/* Orange */
.warning {
  border-color: #c383ff;
  color: #753fa8;
  width: 280px;
  height: 60px;
  font-size: 20px;
}

.warning:hover {
  background: #531e84;
  color: white;
}

div {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px;
}
p {
color:black;
font-family:Cabin;
}
/* Blue */
.info {
  border-color: #2196F3;
  color: dodgerblue;
  width: 170px;
  height: 60px;
  font-size: 20px;
}

.info:hover {
  background: #2196F3;
  color: white;

}

.n {
color: dodgerblue;
}

.n:hover {
color:white;
}
</style>