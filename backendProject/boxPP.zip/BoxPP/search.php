<?php
// Check if the 'error' parameter is present in the URL
if (isset($_GET['error']) && $_GET['error'] === 'fileidnotfound') {
  echo '<style>
input[type=submit] {
  width: 60%;
  background-color: #007ea2;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=text], select {
  width: 60%;
  height: 60px;
  padding: 9px 0px;
  margin: 5px 0;
  display: inline-block;
  border: 2px solid #000;
  border-radius: 6px;
  box-sizing: border-box;
  color:black;
  font-family:monospace;
  font-size:18px;

}

a {
text-decoration: none;
color:red;
font-family:Cabin;
}
div {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px;
}
</style>
<title>BoxPP — Upload File</title>
<div align="center">
<div align="left"><a href="index.html">Home</a>&nbsp;&nbsp; &nbsp;&nbsp;
<a id="top" href="/terms.html"> Terms </a>&nbsp;&nbsp; &nbsp;&nbsp;<a href="/Reports/index.html">Report </a>&nbsp;&nbsp;&nbsp;&nbsp;<span><a href="/donate.html"> Donate </a></span>&nbsp;&nbsp;&nbsp;&nbsp;<span><a href="/about.html"> About</a></span></div>
<img src="logo.png" width="220px" />
<h1 style="color:red; font-family:Cabin;">Search Files</h1>
<form action="submit.php" method="GET" onsubmit="return validateForm();">
  <input type="text" name="filename" placeholder="Enter file name"><br />

<input type="submit" value="Search">
</form>
<p align="left">Help</p>
<div id="errorDiv" style="color: red; font-family: Cabin; margin-top: 5px;">File ID not Found</div>

<script>
  // Function to hide the div after 3 seconds
  setTimeout(function() {
    var errorDiv = document.getElementById("errorDiv");
    if (errorDiv) {
      errorDiv.style.display = "none";
    }
  }, 3000); // 3000 milliseconds = 3 seconds
</script>
</div>';
  die(); // This will stop further execution of the PHP script after displaying the error message
}
?>
<style>
input[type=submit] {
  width: 60%;
  background-color: #007ea2;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=text], select {
  width: 60%;
  height: 60px;
  padding: 9px 0px;
  margin: 5px 0;
  display: inline-block;
  border: 2px solid #000;
  border-radius: 6px;
  box-sizing: border-box;
  color:black;
  font-family:monospace;
  font-size:18px;

}

a {
text-decoration: none;
color:red;
font-family:Cabin;
}
div {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px;
}
</style>
<title>BoxPP — Upload File</title><script>
function showErrorBox() {
  var errorBox = document.createElement('div');
  errorBox.setAttribute('id', 'error-box');
  errorBox.style.border = '2px solid red';
  errorBox.style.backgroundColor = '#f2f2f2';
  errorBox.style.padding = '20px';
  errorBox.style.borderRadius = '5px';
  errorBox.style.position = 'absolute';
  errorBox.style.top = '50%';
  errorBox.style.left = '50%';
  errorBox.style.transform = 'translate(-50%, -50%)';

  var errorMessage = document.createElement('p');
  errorMessage.textContent = 'File ID Not Found.';

  var closeButton = document.createElement('span');
  closeButton.textContent = 'X';
  closeButton.style.color = 'red';
  closeButton.style.float = 'right';
  closeButton.style.cursor = 'pointer';
  closeButton.addEventListener('click', function() {
    errorBox.style.display = 'none';
  });

  errorBox.appendChild(errorMessage);
  errorBox.appendChild(closeButton);
  document.body.appendChild(errorBox);
}

function validateForm() {
  var filenameInput = document.querySelector('input[name="filename"]');
  if (filenameInput.value.trim() === '') {
    showErrorBox();
    return false;
  }
}
</script>
<div align="center">
<div align="left"><a href="index.html">Home</a>&nbsp;&nbsp; &nbsp;&nbsp;
<a id="top" href="/terms.html"> Terms </a>&nbsp;&nbsp; &nbsp;&nbsp;<a href="/Reports/index.html">Report </a>&nbsp;&nbsp;&nbsp;&nbsp;<span><a href="/donate.html"> Donate </a></span>&nbsp;&nbsp;&nbsp;&nbsp;<span><a href="/about.html"> About</a></span></div>
<img src="logo.png" width="220px" />
<h1 style="color:red; font-family:Cabin;">Search Files</h1>
<form action="submit.php" method="GET" onsubmit="return validateForm();">
  <input type="text" name="filename" placeholder="Enter file name"><br />
  <input type="submit" value="Search">
</form>

</div>