<?php
session_start();

// Check if the user is already logged in
if (isset($_SESSION['username'])) {
    header("Location: index.php");
    exit;
}

// Check if the login form is submitted
if (isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Read the login credentials from the JSON file
    $loginData = file_get_contents("login.json");
    $loginData = json_decode($loginData, true);

    // Validate the login credentials
    $isValidUser = false;
    if ($loginData) {
        foreach ($loginData as $user) {
            if ($user['username'] === $username && $user['password'] === $password) {
                $isValidUser = true;
                break;
            }
        }
    }

    if ($isValidUser) {
        // Store the username in a session variable
        $_SESSION['username'] = $username;

        // Redirect to the index.php page
        header("Location: index.php");
        exit;
    } else {
        $errorMessage = "Invalid username or password.";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #0a192f;
            margin: 0;
            padding: 0;
        }

        .container {
            width: 400px;
            margin: 100px auto;
            background-color: #fff;
            border: 1px solid #ccc;
            padding: 20px;
            border-radius: 5px;
            animation: fade-in 0.5s ease-out;
        }

        @keyframes fade-in {
            0% {
                opacity: 0;
                transform: translateY(-100px);
            }
            100% {
                opacity: 1;
                transform: translateY(0);
            }
        }

        h1 {
            text-align: center;
        }

        label {
            display: block;
            margin-bottom: 10px;
            font-weight: bold;
        }

        .input-container {
            position: relative;
        }

        .password-toggle {
            position: absolute;
            top: 35.5%;
            right: 10px;
            transform: translateY(-50%);
            cursor: pointer;
            width: 20px;
            height: 20px;
        }

        input[type="text"],
        input[type="password"] {
            width: 94%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 3px;
            margin-bottom: 20px;
            margin-right: 20px;
            padding-right: 30px;
        }

        button {
            width: 100%;
            padding: 10px;
            background-color: #00adc1;
            border: none;
            color: #fff;
            cursor: pointer;
            border-radius: 3px;
        }

        button:hover {
            background-color: #45a049;
        }

        .error-message {
            text-align: center;
            margin-top: 5px;
            margin-bottom: 5px;
            background-color: #ff523e;
        }

        a {
            text-decoration: none;
        }
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script>
        // Function to toggle password visibility
        function togglePasswordVisibility() {
            var passwordInput = document.getElementById("password");
            var passwordToggle = document.querySelector(".password-toggle");

            if (passwordInput.type === "password") {
                passwordInput.type = "text";
                passwordToggle.innerHTML = '<i style="font-size: 24px" class="fa fa-eye-slash"></i>';
            } else {
                passwordInput.type = "password";
                passwordToggle.innerHTML = '<i style="font-size: 24px" class="fa fa-eye"></i>';
            }
        }
    </script>
</head>
<body><style>
  .box {
    display: inline-block;
    background-color: transparent;
  }

  .box1 {
    margin-top: 10px;
    margin-left: 5px;
  }

  .box2 {
    margin-top: 10px;
    margin-left: 10px;
  }
</style>

<div class="box box1"><img src="logo.svg" alt="Logo • ChatSystem" width="50px"></div>
<div class="box box2"><img src="logo.png" width="200px" height="50px"></div>
    <div class="container">
        <form method="POST" action="">
            <h1 align="center">Login • ChatSystem</h1>
            <div class="form-group">
                <label for="username">Username:</label>
                <input type="text" id="username" name="username" required>
            </div>

            <div class="form-group">
                <label for="password">Password:</label>
                <div class="input-container">
                    <input type="password" id="password" name="password" required>
                    <span class="password-toggle" onclick="togglePasswordVisibility()"><i style="font-size: 24px" class="fa fa-eye"></i></span>
                </div>
            </div>

            <?php if (isset($errorMessage)) : ?>
                <div id="errorMessage" class="error-message"><?php echo $errorMessage; ?></div>
            <?php endif; ?>

            <button type="submit" name="login">Login</button>
        </form>

        <p align="center" class="message">Not registered? <a href="index.php">Create an account</a></p>
    </div>
</body>
</html>
<script>
  // Function to hide the error message after a specified delay
  function hideErrorMessage() {
    var errorMessage = document.querySelector('#errorMessage');
    if (errorMessage) {
      setTimeout(function() {
        errorMessage.style.display = 'none';
      }, 3000); // 3000 milliseconds = 3 seconds
    }
  }

  // Call the hideErrorMessage function when the page finishes loading
  window.addEventListener('load', hideErrorMessage);
</script>
