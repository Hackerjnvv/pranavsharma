<?php
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: sign-up.php");
    exit;
}

$username = $_SESSION['username'];

// Load the list of online users from JSON file
 // Remove the user from the online users list when they log out
if (isset($_GET['logout'])) {
    $logoutUser = $_GET['logout'];
    $index = array_search($logoutUser, $onlineUsers);
    if ($index !== false) {
        unset($onlineUsers[$index]);
        file_put_contents($usersFile, json_encode($onlineUsers));
        // Clear the session data for the user
        unset($_SESSION['username']);
        session_destroy();
        header("Location: login.php"); // Redirect to login page after logout
        exit;
    }
}


?>
<!DOCTYPE html><html><head>
    <title>Chatroom</title>
    <link rel="icon" type="hah.png" href="images/hah.png">
    <link rel="stylesheet" type="text/css" href="css/styles.css">

<style>
    

body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    background-color: #f0f0f0;
}

header {
    background-color: #333;
    color: #fff;
    padding: 10px;
}

h1 {
    margin: 0;
}

.chat-container {
    background-color: #ddd;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    margin: 20px auto;
    max-width: 800px;
    height: 1200px;
    padding: 20px;
    border-radius: 10px;
}

h2 {
    color: #333;
    font-size: 20px;
}

li {
    margin-bottom: 5px;
    color: #555;
}

.list-container {
  max-height: 122px; /* Adjust this value as needed */
  width: 100px;
  overflow-y: scroll;
  overflow-x: scroll;
}

a {
    display: inline-block;
    margin-top: 10px;
    padding: 8px 15px;
    background-color: #ee1111;
    color: #fff;
    text-decoration: none;
    border-radius: 5px;
}

.message-input {
    margin-top: 40px;
    margin-left: 10px;
    background-color: #C8F9FF;
    color: black;
    width: 80%;
    padding: 10px;
    border: 2px solid black;
    border-radius: 10px;
    font-size: 24px;
    font-weight: 500;
    resize: none;
    outline: none;
}

.send-button {
    background-color: #008080;
    color: #fff;
    border: none;
    margin-top: 25px;
    padding: 10px 20px;
    margin-left: 10px;
    border-radius: 5px;
    cursor: pointer;
    font-size: 16px;
}

.scroll-down-button {
    position: fixed;
    bottom: 15%;
    right: 20%;
    display: none;
    background-color: #008080;
    color: #fff;
    border: none;
    padding: 10px;
    border-radius: 10%;
    font-size: 48px;
    cursor: pointer;
}

.chat-history {
    height: 1250px;
    overflow-y: auto;
    padding: 10px;
    background-color: #f9f9f9;
    border-radius: 5px;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    font-size: 10px;
}

.chat-message {
    margin-bottom: 10px;
}


label {
    color: #555;
    font-size: 14px;
    cursor: pointer;
}

#timestamps-checkbox {
    margin-right: 5px;
}


#name-container {
    display: none;
}


@media (max-width: 600px) {
    .message-input {
        width: 60%;
    }
    .send-button {
        margin-left: 5px;
    }
}

   .countdown {
        width: 30px;
        height: 30px;
        cursor: pointer;
    }   
    
    
    
</style>
</head>
<body>

    <header>
        <h1 align="center">Chat System</h1>
    </header>
<a id="autoLogout" href="?logout=<?php echo $username; ?>">Logout</a>

    <label><input type="checkbox" id="timestamps-checkbox" onchange="toggleTimestamps()">View Timestamps</label>
    <button onclick="increaseFontSize()">+</button>
<button onclick="decreaseFontSize()">-</button>
<div class="chat-container">
    
        <div class="chat-history" id="chat-history" onscroll="handleScroll()"></div>
        <div id="name-container">
             <script>
        var userName = '<?php echo $username; ?>';</script>
            
        </div>
        <input type="text" id="message-input" class="chat-input message-input" placeholder="Type your message...." onkeyup="insertLineBreaks(event)">
        <button onclick="sendMessage()" class="send-button">Send</button>
        <button onclick="scrollToBottom()" class="scroll-down-button">↓</button>
    </div>

    <audio id="receive-sound">
        <source src="media/wrong-answer-129254.mp3" type="audio/wav">
    </audio>

    <audio id="send-sound">
        <source src="media/sent.mp3" type="audio/wav">
    </audio>

<script>
  function increaseFontSize() {
    var chatHistories = document.querySelectorAll(".chat-history");
    chatHistories.forEach(function(chatHistory) {
      var currentFontSize = window.getComputedStyle(chatHistory).fontSize;
      var currentSize = parseFloat(currentFontSize);
      if (currentSize < 40) {
        chatHistory.style.fontSize = (currentSize + 5) + "px";
      }
    });
  }

  function decreaseFontSize() {
    var chatHistories = document.querySelectorAll(".chat-history");
    chatHistories.forEach(function(chatHistory) {
      var currentFontSize = window.getComputedStyle(chatHistory).fontSize;
      var currentSize = parseFloat(currentFontSize);
      if (currentSize > 1) {
        chatHistory.style.fontSize = (currentSize - 10) + "px";
      }
    });
  }
</script>

<script>
  function increaseFontSize() {
    var chatHistories = document.querySelectorAll(".chat-history");
    chatHistories.forEach(function(chatHistory) {
      var currentFontSize = window.getComputedStyle(chatHistory).fontSize;
      var currentSize = parseFloat(currentFontSize);
      if (currentSize < 40) {
        chatHistory.style.fontSize = (currentSize + 5) + "px";
      }
    });
  }

  function decreaseFontSize() {
    var chatHistories = document.querySelectorAll(".chat-history");
    chatHistories.forEach(function(chatHistory) {
      var currentFontSize = window.getComputedStyle(chatHistory).fontSize;
      var currentSize = parseFloat(currentFontSize);
      if (currentSize > 1) {
        chatHistory.style.fontSize = (currentSize - 10) + "px";
      }
    });
  }

  document.querySelector(".chat-history").addEventListener("input", function() {
    var text = this.innerText;
    if (text.length > 50) {
      var lines = Math.ceil(text.length / 50);
      var newText = "";
      for (var i = 0; i < lines; i++) {
        newText += text.substr(i * 50, 50) + "<br>";
      }
      this.innerHTML = newText;
    }
  });
</script>
    <script>
       
        var showTimestamps = true;
        var autoScroll = true;

        // Function to play the receive sound effect
        function playReceiveSound() {
            var receiveSound = document.getElementById('receive-sound');
            receiveSound.play();
        }

        // Function to play the send sound effect
        function playSendSound() {
            var sendSound = document.getElementById('send-sound');
            sendSound.play();
        }

        // Function to send messages
        function sendMessage() {
            var messageInput = document.getElementById('message-input');
            var message = messageInput.value.trim();

            if (userName === '' || message === '') {
                return;
            }

            var chatMessage = {
                name: userName,
                message: message
            };

            // Clear input field
            messageInput.value = '';

            // Play send sound effect
            playSendSound();

            // Send the chat message to the server
            sendToServer(chatMessage);
        }

        // Function to send chat message to the server using AJAX
        function sendToServer(chatMessage) {
            var xhttp = new XMLHttpRequest();
            xhttp.onreadystatechange = function () {
                if (this.readyState == 4 && this.status == 200) {
                    // Message sent successfully
                }
            };
            xhttp.open("POST", "save-message.php", true);
            xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
            xhttp.send("message=" + JSON.stringify(chatMessage));
        }

        // Function to toggle timestamps
        function toggleTimestamps() {
            showTimestamps = document.getElementById('timestamps-checkbox').checked;
            displayMessages(chatMessages);
        }

        // Function to periodically retrieve chat messages from the server
        function retrieveMessages() {
            var xhttp = new XMLHttpRequest();
            xhttp.onreadystatechange = function () {
                if (this.readyState == 4 && this.status == 200) {
                    var chatMessages = JSON.parse(this.responseText);
                    displayMessages(chatMessages);
                }
            };
            xhttp.open("GET", "get-messages.php", true);
            xhttp.send();
        }

        // Function to display chat messages on the page
        function displayMessages(chatMessages) {
            var chatHistory = document.getElementById('chat-history');
            chatHistory.innerHTML = '';

            chatMessages.forEach(function (chatMessage) {
                var messageDiv = document.createElement('div');
                messageDiv.classList.add('chat-message');

                var timestamp = '';
                if (showTimestamps) {
                    timestamp = ' ' + chatMessage.serverTime;
                }

                var messageContent = '';
                var isMyMessage = chatMessage.name === userName; // Check if it's your message

                if (isMyMessage) {
                    messageContent += '<strong style="color: green;">' + chatMessage.name + '</strong>' + timestamp + ': ';
                } else {
                    messageContent += '<strong style="color: blue;">' + chatMessage.name + '</strong>' + timestamp + ': ';
                }

                messageContent += '<span>' + chatMessage.message + '</span>';
                messageDiv.innerHTML = messageContent;

                chatHistory.appendChild(messageDiv);
            });

            // Play receive sound effect
            playReceiveSound();

            // Scroll to the bottom of the chat history if auto-scrolling is enabled
            if (autoScroll) {
                chatHistory.scrollTop = chatHistory.scrollHeight;
            } else {
                // Show scroll down button
                showScrollDownButton();
            }
        }

        // Adjust the textarea size based on content
        function adjustTextarea(textarea) {
            textarea.style.height = 'auto';
            textarea.style.height = (textarea.scrollHeight) + 'px';
        }

        // Handle scroll event in chat history
        function handleScroll() {
            var chatHistory = document.getElementById('chat-history');
            var scrollDownButton = document.querySelector('.scroll-down-button');

            if (chatHistory.scrollTop < chatHistory.scrollHeight - chatHistory.clientHeight - 50) {
                // User is manually scrolling up, disable auto-scrolling
                autoScroll = false;
                // Show scroll down button
                showScrollDownButton();
            } else {
                // User is at the bottom, enable auto-scrolling
                autoScroll = true;
                // Hide scroll down button
                hideScrollDownButton();
            }
        }

        // Scroll to the bottom of the chat history
        function scrollToBottom() {
            var chatHistory = document.getElementById('chat-history');
            chatHistory.scrollTop = chatHistory.scrollHeight;
            // Hide scroll down button
            hideScrollDownButton();
        }

        // Show the scroll down button
        function showScrollDownButton() {
            var scrollDownButton = document.querySelector('.scroll-down-button');
            scrollDownButton.style.display = 'block';
        }

        // Hide the scroll down button
        function hideScrollDownButton() {
            var scrollDownButton = document.querySelector('.scroll-down-button');
            scrollDownButton.style.display = 'none';
        }

        // Insert line breaks after every multiple of 15 characters
        function insertLineBreaks(event) {
            var messageInput = document.getElementById('message-input');
            var message = messageInput.value;
            var messageLength = message.length;

            if (messageLength % 35 === 0 && messageLength !== 0) {
                messageInput.value += '';
            }
        }

        // Periodically retrieve messages every 1 second
        setInterval(retrieveMessages, 1000);

        window.onload = () => {
            let bannerNode = document.querySelector('[alt="www.000webhost.com"]').parentNode.parentNode;
            bannerNode.parentNode.removeChild(bannerNode);

            // Programmatically trigger the button click after 5 seconds
            setTimeout(function() {
                var setNameButton = document.querySelector('.set-name-button');
                setNameButton.click();
            }, 5000);
        }
    </script>


</body></html>