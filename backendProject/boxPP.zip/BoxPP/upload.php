<?php
echo '<script>
if (performance.navigation.type === 1) {
  // Redirect the user to a different page
  window.location.href = "https://boxpp.000webhostapp.com/index.html";
}
</script>
<style>
img[alt*="000webhost"],
img[alt*="000webhost"][style],
img[src*="000webhost"],
img[src*="000webhost"][style],
body > div:nth-last-of-type(1)[style]{
	opacity: 0 !important;
	pointer-events:none !important;
	width: 0px !important;
	height: 0px !important;
	visibility:hidden !important;
	display:none !important;
}
</style>
<!DOCTYPE HTML>
<head>
<meta name="theme-color" content="#151615"> <body bgcolor="#07000B">
<link href="font-file/font.css" rel="stylesheet">
<title>BoxPP — Status • Uploaded Files</title>
<div align="center">
<div id="nav" align="center"><img src="logo.png" width="30px" />&nbsp;&nbsp;<a href="/index.html"> Home </a>&nbsp;&nbsp; &nbsp;&nbsp;<a id="top" href="/terms.html"> Terms </a>&nbsp;&nbsp; &nbsp;&nbsp;<a href="/Reports/index.html">Report </a> <span> &nbsp;&nbsp;&nbsp;&nbsp;<a href="search.php">Search</a><span>&nbsp;&nbsp;&nbsp;&nbsp;<a href="/donate.html"> Donate </a></span>&nbsp;&nbsp;&nbsp;&nbsp;<span><a href="/about.html"> About</a></span></div>
    <div style="padding: 40px;"></div>

<h1 style="color:red; font-family:Montserrat;">BoxPP • Status • Uploaded Files</h1></p>
 <button class="home"><a class="n1" href="index.html">Upload Files Now</button></a><div style="background-color: #1C1C1C; margin:10px; padding:0.4px;"></div><p align="right"><button id="toggleButton">HTML Embed Code</button>';

// File Upload
if (isset($_POST['submit'])) {
    $destinationDirectory = 'uploads/';
    $files = $_FILES['file'];
    $fileCount = count($files['tmp_name']); // Count the number of files

    // Loop through each uploaded file
    $uploadSuccess = false; // Variable to track if any file was uploaded successfully

    foreach ($files['tmp_name'] as $index => $tmpName) {
        $fileName = $files['name'][$index];
        $fileTmpName = $tmpName;
        $fileSize = $files['size'][$index];
        $fileError = $files['error'][$index];

        // Generate a unique filename with a random number
        $randomNumber = rand(100000000000, 999999999999);
        $newFileName = 'BoxPP-' . uniqid() . $randomNumber . '-' . $fileName;
        $destinationPath = $destinationDirectory . $newFileName;

        if ($fileError === 0) {
            if (move_uploaded_file($fileTmpName, $destinationPath)) {
                $uploadSuccess = true; // Set the variable to true if at least one file was uploaded successfully
                $embedCode = '<iframe src="https://boxpp.000webhostapp.com/' . $destinationPath . '" width="500px" height="300px" frameborder="0" allowfullscreen></iframe>';
                $fileUrl = 'https://boxpp.000webhostapp.com/' . $destinationPath;
                
                echo '<div align="center">';
             
                echo '<div class="filename" id="fileDiv" align="center">' . $newFileName . '</div><br / ><button id="myButton" onclick="copyText()" class="kopy" >Copy File Id</button><br />';
                
                echo '
<br /><button class="info"> <a class="n" href="' . $fileUrl . '" download>Download</a></button>&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp; <button class="success" onclick="copyFileLink(this)" data-link="' . $fileUrl . '">Copy File Link</button><div class="toggleDiv" style="display:none;"><button class="warning" onclick="copyEmbedCode(this)" data-embed="' . htmlentities($embedCode) . '">Copy HTML Embed Code</button><textarea readonly style="width: 100%; height: 500px; color: #fff; font-family: Monaco, monospace;">' . htmlentities($embedCode) . '</textarea></div>';
                echo '</div>';
                echo '</div>';
                echo '<div align="center">';
                echo '</div></div></div>';
                echo '</div><div style="background-color: #1C1C1C; margin:10px; padding: 0.8px;"></div>';
            } else {
                echo 'Failed to save the file.  <button class="home"><a href="index.html">Upload Files Now</button>';
            }
        } else {
            echo '<p style="font-family:Montserrat; color:red; font-size:36px;">Error occurred during file upload.</p>';
        }
    }
}

?>

<style>
.btn {
  border: 2px solid black;
  background-color: white;
  color: black;
  padding: 14px 28px;
  font-size: 16px;
  cursor: pointer;
}

/* Green */
.success {
  border-color: #04AA6D;
  color: green;
  width: 170px;
  height: 60px;
  font-size: 20px;
}

.success:hover {
  background-color: #04AA6D;
  color: white;
  width: 170px;
  height: 60px;
  font-size: 20px;
}
.filename {
font-family:Cabin;
font-size:16px;
overflow:scroll;
}
/* Blue */
.info {
  border-color: #2196F3;
  color: dodgerblue;
  width: 170px;
  height: 60px;
  font-size: 20px;
}

.info:hover {
  background: #2196F3;
  color: white;

}

/* Orange */
.warning {
  border-color: #c383ff;
  color: #753fa8;
  width: 280px;
  height: 60px;
  font-size: 20px;
}

.warning:hover {
  background: #531e84;
  color: white;
}

/* Purple */
.home {
  border-color: #1f7284;
  background-color: 74ffb4;
  color: #000;
  width: 280px;
  height: 60px;
  font-size: 20px;
}

.home:hover {
  background: #531e84;
  color: white;
}

/* Purple */
#html {
  border-color: #c3b276;
  color: #000;
  width: 150px;
  height: 50px;
  font-size: 16px;
}

hr {
color: #1C1C1C;
}

#html:hover {
  background: #531e84;
  color: white;
}

/* Gray */
#toggleButton {
  border-color: #ccc;
  color: #000;
  width: 200px;
  height: 50px;
  font-size: 16px;
}

#toggleButton:hover {
  background: #aaa;
  color: white;
}

/* Navy Blue */
.kopy {
  border-color: #3030B0;
  color: #3030B0;
  width: 180px;
  height: 50px;
  font-size: 20px;
}

.kopy:hover {
  background: #000070;
  color: white;
}
.n {
color: dodgerblue;
}

.n:hover {
color:white;
}
.n1 {
color: black;
}

.n1:hover {
color: white;
}
</style>





<style>
  .progress-bar {
        width: 100%;
        height: 20px;
        background-color: #f2f2f2;
        border-radius: 4px;
        overflow: hidden;
    }

    .progress-bar-inner {
        height: 100%;
        background-color: #4c99ff;
        width: 0%;
        transition: width 0.3s ease-in-out;
    }

    .progress-bar-text {
        margin-top: 8px;
        text-align: center;
        color: #333;
        font-weight: bold;
    }


input[type=file] {
  margin: 50px;
  padding: 200px;
  display: inline-block;
  width: 40%;
  padding: 120px 0 0 0;
  border: 1px dashed black;
  height: 100px;
  overflow: hidden;
  -webkit-box-sizing: border-box;
  -moz-box-sizing: border-box;
  box-sizing: border-box;
  background: url('https://cdn1.iconfinder.com/data/icons/hawcons/32/698394-icon-130-cloud-upload-512.png') center center no-repeat #ccc;
  border-radius: 20px;
  background-size: 60px 60px;
}

input[type=submit] {
  width: 60%;
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}


#nav {
    position: fixed;
    top: 0%;
    left: 0%;
    display: flex;
    width: 100%;
    font-size: 30px;
    padding: 20px;
    background-color: #15161F;
    transition: opacity 0.5s ease-in-out;
    border: none !important;
    box-shadow: 0 2px 25px rgba(48, 50, 67, 0.5);
  }


div {
  border-radius: 5px;
  background-color: #000;
  padding: 20px;
}
.output {
position: relative;
left:0px;
font-family: Montserrat;
font-size: 12px;

}

#file-upload-filename {
font-family: Montserrat;
}
a {
text-decoration: none;
color: #fff;
font-family:Montserrat;
}
#selected-files {
font-family: Montserrat;
}
#fileDiv {
    color: white;
    font-weight: 600;
    font-family: Cabin;
}
</style>
 </body>
</html>
<script>
    function copyEmbedCode(button) {
        var textarea = button.parentNode.parentNode.querySelector('textarea');
        textarea.select();
        document.execCommand('copy');
        alert('Embed code copied to clipboard.');
    }

    function copyFileLink(button) {
        var fileUrl = button.getAttribute('data-link');
        var tempInput = document.createElement('input');
        tempInput.value = fileUrl;
        document.body.appendChild(tempInput);
        tempInput.select();
        document.execCommand('copy');
        document.body.removeChild(tempInput);
        alert('File link copied to clipboard.');
    }

    
</script>
<script>
function toggleTextAreas() {
  var textAreas = document.getElementsByTagName("textarea");

  for (var i = 0; i < textAreas.length; i++) {
    var textarea = textAreas[i];

    if (textarea.style.display === "none") {
      textarea.style.display = "block";
    } else {
      textarea.style.display = "none";
    }
  }
}
</script><script>
      function copyText() {
  // Get the text content of the div
  var text = document.getElementById("fileDiv").textContent;

  // Create a temporary input element
  var tempInput = document.createElement("input");
  
  // Set the value of the input to the text content
  tempInput.value = text;

  // Append the input element to the body
  document.body.appendChild(tempInput);

  // Select the text in the input element
  tempInput.select();

  // Copy the selected text to the clipboard
  document.execCommand("copy");

  // Remove the temporary input element
  document.body.removeChild(tempInput);

  // Provide some feedback to the user
  alert("File Id copied to clipboard!");
}

    </script><script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<script>
$(document).ready(function() {
  $('#toggleButton').click(function() {
    $('.toggleDiv').toggle();
  });
});
</script>