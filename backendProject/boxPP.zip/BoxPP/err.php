<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <style>
         img[alt*="000webhost"],
img[alt*="000webhost"][style],
img[src*="000webhost"],
img[src*="000webhost"][style],
body > div:nth-last-of-type(1)[style]{
	opacity: 0 !important;
	pointer-events:none !important;
	width: 0px !important;
	height: 0px !important;
	visibility:hidden !important;
	display:none !important;
}
        .main__bg {
        background-image: linear-gradient(-60deg, #10132B 50%, #141839 50%);
        animation: slide 3s ease-in-out infinite alternate;
        position: fixed;
        top: 0;
        bottom: 0;
        left: -50%;
        right: -50%;
        opacity: 0.5;
        z-index: -1;
        }
         
        .layer1 {
        animation-direction: alternate-reverse;
        animation-duration: 3s;
        }
         
        .layer2 {
        animation-duration: 4s;
        }
         
        @keyframes slide {
        0% {
            transform: translateX(-25%);
        }
        100% {
            transform: translateX(25%);
        }
        }
    </style>
</head>

<body style="font-family: Arial;">
      <img src="/logo.png" width="80px" alt="BoxPP Logo">
      <h2 style="font-size: 30px; color: white;">Sorry!</h2>
        <h1 style="color: #D7A3B2; font-weight:bold; font-size: 36px;">The file you requested cannot be found.</h1>
<?php
// Get the requested URL from the query parameter
$requested_url = $_GET['url'];

// Remove the "uploads/" part from the URL
$accessed_file = str_replace('uploads/', '', $requested_url);

// Check if $accessed_file is empty or contains only spaces
if (trim($accessed_file) !== '') {
    echo '<h3 style="color: #C78A9B;">File Requested: <font color="#E88291">' . htmlspecialchars($accessed_file) . '</font></h3>';
}
?>
 <div style="display: flex;"><button onclick="window.location.href='/Reports';" style="width: 35%; height: 45px; background-color: #FF3863; color: #000; font-weight: 600; border: none;">Report</button>&nbsp;<button onclick="window.location.href='/index.html';"  style="width: 65%; height: 45px; background-color: #3866FF; font-weight: 600; border: none; color: #fff;">Home</button></div>
     <div class="main__bg"></div>
    <div class="main__bg layer1"></div>
    <div class="main__bg layer2"></div>
</body>

</html>