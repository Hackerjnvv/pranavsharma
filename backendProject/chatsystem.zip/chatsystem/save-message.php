<?php
// Get the chat message from the POST request
$message = $_POST['message'];
$chatMessage = json_decode($message, true);

// Add the server time to the chat message
$chatMessage['serverTime'] = date('Y-m-d H:i:s'); // This gets the current server time in the format 'YYYY-MM-DD HH:mm:ss'

// Read the existing messages from the file
$messages = file_get_contents('messages.json');
$messages = json_decode($messages, true);

// Add the new message to the array
$messages[] = $chatMessage;

// Write the updated messages back to the file
file_put_contents('messages.json', json_encode($messages));
?>
