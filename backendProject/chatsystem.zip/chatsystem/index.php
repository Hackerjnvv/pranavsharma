<?php
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: sign-up.php");
    exit;
}

$username = $_SESSION['username'];
$_SESSION['my_variable'] = $username;
$_SESSION['online'] = true;

// Check if the user is online
if(isset($_SESSION['online']) && $_SESSION['online']) {
}
// Load the list of online users from JSON file
$onlineUsers = [];
$usersFile = 'online_users.json';
if (file_exists($usersFile)) {
    $onlineUsers = json_decode(file_get_contents($usersFile), true);
}

// Add the current user to the online users list
if (!in_array($username, $onlineUsers)) {
    $onlineUsers[] = $username;
    file_put_contents($usersFile, json_encode($onlineUsers));
}

// Remove the user from the online users list when they log out
if (isset($_GET['logout'])) {
    $logoutUser = $_GET['logout'];
    $index = array_search($logoutUser, $onlineUsers);
    if ($index !== false) {
        unset($onlineUsers[$index]);
        file_put_contents($usersFile, json_encode($onlineUsers));
        // Clear the session data for the user
        unset($_SESSION['username']);
        session_destroy();
        header("Location: login.php"); // Redirect to login page after logout
        exit;
    }
}


?>
<!DOCTYPE html><html><head>
    <title>Chatroom</title>
    <link rel="icon" type="hah.png" href="images/hah.png">

<meta charset="UTF-8">

<style>
    

body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    background-color: #f0f0f0;
}

header {
    background-color: #333;
    color: #fff;
    padding: 10px;
}

h1 {
    margin: 0;
}

.chat-container {
    background-color: #ddd;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    margin: 20px auto;
    max-width: 800px;
    height: 1400px;
    padding: 20px;
    border-radius: 10px;
}

h2 {
    color: #333;
    font-size: 20px;
}

li {
    margin-bottom: 5px;
    color: #555;
}

.list-container {
  max-height: 122px; /* Adjust this value as needed */
  width: 100px;
  overflow-y: scroll;
  overflow-x: scroll;
}

#autoLogout {
    display: inline-block;
    margin-top: 10px;
    padding: 8px 15px;
    background-color: #ee1111;
    color: #fff;
    text-decoration: none;
    border-radius: 5px;
}

.style {
	display: inline-block;
    margin-top: -10px;
    padding: 8px 15px;
    background-color: #008080;
    color: #fff;
    text-decoration: none;
    font-size: 14px;
    border-radius: 5px;
    border: none;
    }
    
.style2 {
	display: inline-block;
    margin-left: -5px;
    padding: 8px 15px;
    background-color: #008080;
    color: #fff;
    text-decoration: none;
    border-radius: 5px;
    font-size: 12px;
    border: none;
    }
   
.style3 {
  display: inline-block;
    margin-left: -5px;
    padding: 8px 15px;
    background-color: #008080;
    color: #fff;
    text-decoration: none;
    border-radius: 5px;
    font-size: 12px;
    border: none;
    }
.message-input {
    margin-top: 40px;
    margin-left: 10px;
    background-color: #C8F9FF;
    color: black;
    width: 80%;
    padding: 10px;
    border: 2px solid black;
    border-radius: 10px;
    font-size: 24px;
    font-weight: 500;
    resize: none;
    outline: none;
}

.send-button {
    background-color: #008080;
    color: #fff;
    border: none;
    margin-top: 25px;
    padding: 10px 20px;
    margin-left: 10px;
    border-radius: 5px;
    cursor: pointer;
    font-size: 16px;
}

.scroll-down-button {
    position: fixed;
    right: 20%;
    bottom: 20%;
    background-color: #78B1B1;
    color: #fff;
font-size: 48px; /* black or any other color for arrow */
    border: none;
    border-radius: 50%;
    width: 60px;
    height: 60px;
    box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.2); /* adjust shadow as needed */
    cursor: pointer;
    transition: transform 0.3s ease;
    display: flex;
    align-items: center;
    justify-content: center;
    text-align: center;
    font-weight: bold;
    line-height: 1; /* Adjust line height to prevent text from shifting */
}

.scroll-down-button:hover {
    transform: translateY(2px); /* adjust the amount of downward movement */
}

.chat-history {
    display: block;
    white-space: pre-line; /* Preserve line breaks */
    word-wrap: break-word; /* Wrap long words */
    font-family: Arial, sans-serif;
    font-size: 16px;
    line-height: 1.6;
    color: #333;
    background-color: #f7f7f7;
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 5px;
    height: 90%;
    overflow-y: auto;
}

.chat-message {
    margin-bottom: 10px;
}


label {
    color: #fff;
    font-size: 16px;
    cursor: pointer;
}

#timestamps-checkbox {
    margin-right: 5px;
}


#name-container {
    display: none;
}


@media (max-width: 600px) {
    .message-input {
        width: 60%;
    }
    .send-button {
        margin-left: 5px;
    }
}

   .countdown {
        width: 30px;
        height: 30px;
        cursor: pointer;
    }   
    
body {
    margin: 0;
    padding: 0;
    font-family: Arial, sans-serif;
}

.menu-toggle {
    width: 30px;
    height: 30px;
    position: fixed;
    top: 20px;
    left: 20px;
    z-index: 9999;
    cursor: pointer;
}

.line {
    width: 100%;
    height: 3px;
    background-color: #000;
    margin: 5px 0;
    transition: all 0.3s ease;
    background-color: white;
}

.menu-toggle.active .line:nth-child(1) {
    transform: rotate(45deg) translate(5px, 5px);
}

.menu-toggle.active .line:nth-child(2) {
    opacity: 0;
}

.menu-toggle.active .line:nth-child(3) {
    transform: rotate(-45deg) translate(5px, -5px);
}

.menu {
    position: fixed;
    top: 0;
    left: -250px;
    width: 250px;
    height: 100%;
    background-color: rgba(50, 50, 50, 0.5); /* Adjust the alpha value for desired blur effect */
    backdrop-filter: blur(10px); /* Adjust the blur radius */
    transition: all 0.2s ease;
}

.menu ul {
    list-style: none;
    padding: 0;
    margin: 100px 20px;
}

.menu ul li {
    margin-bottom: 20px;
}

.menu ul li a {
    color: #fff;
    text-decoration: none;
    font-size: 20px;
}

.menu-toggle.active + .menu {
    left: 0;
}

xmp {
    display: block;
    white-space: pre-line; /* Preserve line breaks */
    font-family: Arial, sans-serif;
    line-height: 1.6;
    color: #333;
    background-color: #f7f7f7;
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 5px;
}
    
</style>
</head>
<body>

    <header>
        <h1 align="center">Chat System</h1>
    </header>

  <div class="menu-toggle">
        <div class="line"></div>
        <div class="line"></div>
        <div class="line"></div>
    </div>
    <div class="menu">
        <ul>
        	<div style="background-color: #000; color: #fff;" align="center">Profile</div>
        	<li><span style="font-size: 16px; color: #fff; font-weight: 800;"><?php echo $username; ?></span>&nbsp; &nbsp;<a id="autoLogout" href="?logout=<?php echo $username; ?>">Logout</a></li>
      <div style="background-color: #000; color: #fff;" align="center">Chat Settings</div>  <br>
<li><label class="style" for="timestamps-checkbox"> Show Timestamp</label>    <input type="checkbox" id="timestamps-checkbox" onchange="toggleTimestamps()" checked></li>
          <li><button class="style2" onclick="increaseFontSize()">Increase Font Size</button></li>
          <li>
<button class="style3" onclick="decreaseFontSize()">Decrese Font Size</button></li>
<li><a href="#" id="fullscreenLink">Open in full screen</a>
</li>
<div style="background-color: #000; color: #fff;" align="center">Website</div>
<li><a href="#">Home</a></li>
            <li><a href="#">About</a></li>
            <li><a href="#">Contact</a></li>
        </ul>
    </div>
    
    <div class="chat-container">


        <div class="chat-history" id="chat-history" onscroll="handleScroll()"><p align="center">
<img src="loading.gif" width="250px" alt="loading messages, please wait" />
<h1 align="center" style="font-size:80px;"><u>Please Wait</u></h1><br><p style="font-size: 40px;">The message size is <?php
$file = 'messages.json'; // Specify the path to your file

if (file_exists($file)) {
    $fileSize = filesize($file);
    if ($fileSize < 1024) {
        echo "less than 1 KB, so it usually takes a few moments. Please ensure your internet connection is stable and that JavaScript is allowed in your browser.</p>";
    } elseif ($fileSize < 1024 * 1024) {
        echo "less than 1 MB, so it usually takes a few moments. Please ensure your internet connection is stable and that JavaScript is allowed in your browser.</p>";
    } elseif ($fileSize < 5 * 1024 * 1024) {
        echo "less than 10 MB, so it usually takes a few moments. Please ensure your internet connection is stable and that JavaScript is allowed in your browser.</p>";
    } else {
        $fileSizeInMB = round($fileSize / (1024 * 1024), 2);
        echo $fileSizeInMB . "MB, so please be patience. Please ensure your internet connection is stable and that JavaScript is allowed in your browser.</p>";
    }
} else {
    echo "File does not exist";
}
?>
</div>
        <div id="name-container">
             <script>
        var userName = '<?php echo $username; ?>';</script>
            
        </div>
        <input type="text" id="message-input" class="chat-input message-input" placeholder="Type your message...." onkeyup="insertLineBreaks(event)">
        <button onclick="sendMessage()" class="send-button">Send</button>
        <button onclick="scrollToBottom()" class="scroll-down-button">↓</button>
    </div>

    <audio id="receive-sound">
        <source src="media/wrong-answer-129254.mp3" type="audio/wav">
    </audio>

    <audio id="send-sound">
        <source src="media/sent.mp3" type="audio/wav">
    </audio>

    <script>
       
        var showTimestamps = true;
        var autoScroll = true;

        // Function to play the receive sound effect
        function playReceiveSound() {
            var receiveSound = document.getElementById('receive-sound');
            receiveSound.play();
        }

        // Function to play the send sound effect
        function playSendSound() {
            var sendSound = document.getElementById('send-sound');
            sendSound.play();
        }

        // Function to send messages
        function sendMessage() {
            var messageInput = document.getElementById('message-input');
            var message = messageInput.value.trim();

            if (userName === '' || message === '') {
                return;
            }

            var chatMessage = {
                name: userName,
                message: message
            };

            // Clear input field
            messageInput.value = '';

            // Play send sound effect
            playSendSound();

            // Send the chat message to the server
            sendToServer(chatMessage);
        }

        // Function to send chat message to the server using AJAX
        function sendToServer(chatMessage) {
            var xhttp = new XMLHttpRequest();
            xhttp.onreadystatechange = function () {
                if (this.readyState == 4 && this.status == 200) {
                    // Message sent successfully
                }
            };
            xhttp.open("POST", "save-message.php", true);
            xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
            xhttp.send("message=" + JSON.stringify(chatMessage));
        }

       function increaseFontSize() {
    var chatHistories = document.querySelectorAll(".chat-history");
    chatHistories.forEach(function(chatHistory) {
      var currentFontSize = window.getComputedStyle(chatHistory).fontSize;
      var currentSize = parseFloat(currentFontSize);
      if (currentSize < 40) {
        chatHistory.style.fontSize = (currentSize + 5) + "px";
      }
    });
  }

  function decreaseFontSize() {
    var chatHistories = document.querySelectorAll(".chat-history");
    chatHistories.forEach(function(chatHistory) {
      var currentFontSize = window.getComputedStyle(chatHistory).fontSize;
      var currentSize = parseFloat(currentFontSize);
      if (currentSize > 1) {
        chatHistory.style.fontSize = (currentSize - 10) + "px";
      }
    });
  }

  // Automatically insert <br> tag after 140 characters
  document.querySelector(".chat-history").addEventListener("input", function() {
    var text = this.innerText;
    if (text.length > 140) {
      var lines = Math.ceil(text.length / 140);
      var newText = "";
      for (var i = 0; i < lines; i++) {
        newText += text.substr(i * 140, 140) + "<br>";
      }
      this.innerHTML = newText;
    }
  });
       
 // Function to toggle timestamps
        function toggleTimestamps() {
            showTimestamps = document.getElementById('timestamps-checkbox').checked;
            displayMessages(chatMessages);
        }

        // Function to periodically retrieve chat messages from the server
        function retrieveMessages() {
            var xhttp = new XMLHttpRequest();
            xhttp.onreadystatechange = function () {
                if (this.readyState == 4 && this.status == 200) {
                    var chatMessages = JSON.parse(this.responseText);
                    displayMessages(chatMessages);
                }
            };
            xhttp.open("GET", "get-messages.php", true);
            xhttp.send();
        }

// Function to display chat messages on the page
function displayMessages(chatMessages) {
    var chatHistory = document.getElementById('chat-history');
    chatHistory.innerHTML = '';

    chatMessages.forEach(function (chatMessage) {
        var messageDiv = document.createElement('div');
        messageDiv.classList.add('chat-message');

        var timestamp = '';
        if (showTimestamps) {
            var originalTimestamp = new Date(chatMessage.serverTime);
var adjustedTimestamp = new Date(originalTimestamp.getTime() - (6 * 60 * 60 * 1000 + 30 * 60 * 1000)); // Subtract 6 hours and 30 minutes
var day = adjustedTimestamp.getDate();
var month = adjustedTimestamp.getMonth() + 1; // Add 1 because getMonth() returns zero-based index
var year = adjustedTimestamp.getFullYear();
var hours = adjustedTimestamp.getHours();
var minutes = adjustedTimestamp.getMinutes();
var seconds = adjustedTimestamp.getSeconds();

// Convert hours to 12-hour format with leading zero and determine AM or PM
var ampm = hours >= 12 ? 'AM' : 'PM';
hours = hours % 12;
hours = hours ? padNumber(hours) : '12'; // Handle midnight (0 hours) as 12 PM
hours = hours === '00' ? '12' : hours; // Adjust hours for midnight
minutes = padNumber(minutes); // Pad with leading zero if needed
seconds = padNumber(seconds); // Pad with leading zero if needed

timestamp = ' [' + padNumber(day) + '/' + padNumber(month) + '/' + year + ' ' + hours + ':' + minutes + ':' + seconds + ' ' + ampm + ']';

// Function to pad single-digit numbers with a leading zero
function padNumber(number) {
    return number < 10 ? '0' + number : number;
}
            
        }

        var messageContent = '';
        var isMyMessage = chatMessage.name === userName; // Check if it's your message

        if (isMyMessage) {
            messageContent += '<strong style="color: green;">' + chatMessage.name + '</strong>' + timestamp + ': ';
        } else {
            messageContent += '<strong style="color: blue;">' + chatMessage.name + '</strong>' + timestamp + ': ';
        }

        messageContent += '<span><xmp>' + chatMessage.message + '</xmp></span>';
        messageDiv.innerHTML = messageContent;

        chatHistory.appendChild(messageDiv);
    });

    // Play receive sound effect
    playReceiveSound();

    // Scroll to the bottom of the chat history if auto-scrolling is enabled
    if (autoScroll) {
        chatHistory.scrollTop = chatHistory.scrollHeight;
    } else {
        // Show scroll down button
        showScrollDownButton();
    }
}
        // Adjust the textarea size based on content
        function adjustTextarea(textarea) {
            textarea.style.height = 'auto';
            textarea.style.height = (textarea.scrollHeight) + 'px';
        }

        // Handle scroll event in chat history
        function handleScroll() {
            var chatHistory = document.getElementById('chat-history');
            var scrollDownButton = document.querySelector('.scroll-down-button');

            if (chatHistory.scrollTop < chatHistory.scrollHeight - chatHistory.clientHeight - 50) {
                // User is manually scrolling up, disable auto-scrolling
                autoScroll = false;
                // Show scroll down button
                showScrollDownButton();
            } else {
                // User is at the bottom, enable auto-scrolling
                autoScroll = true;
                // Hide scroll down button
                hideScrollDownButton();
            }
        }

        // Scroll to the bottom of the chat history
        function scrollToBottom() {
            var chatHistory = document.getElementById('chat-history');
            chatHistory.scrollTop = chatHistory.scrollHeight;
            // Hide scroll down button
            hideScrollDownButton();
        }

        // Show the scroll down button
        function showScrollDownButton() {
            var scrollDownButton = document.querySelector('.scroll-down-button');
            scrollDownButton.style.display = 'block';
        }

        // Hide the scroll down button
        function hideScrollDownButton() {
            var scrollDownButton = document.querySelector('.scroll-down-button');
            scrollDownButton.style.display = 'none';
        }

        // Insert line breaks after every multiple of 15 characters
        function insertLineBreaks(event) {
            var messageInput = document.getElementById('message-input');
            var message = messageInput.value;
            var messageLength = message.length;

            if (messageLength % 35 === 0 && messageLength !== 0) {
                messageInput.value += '';
            }
        }

        // Periodically retrieve messages every 1 second
        setInterval(retrieveMessages, 1000);

        window.onload = () => {
            let bannerNode = document.querySelector('[alt="www.000webhost.com"]').parentNode.parentNode;
            bannerNode.parentNode.removeChild(bannerNode);

            // Programmatically trigger the button click after 5 seconds
            setTimeout(function() {
                var setNameButton = document.querySelector('.set-name-button');
                setNameButton.click();
            }, 5000);
        }
    </script>
<script>
	document.querySelector('.menu-toggle').addEventListener('click', function() {
    this.classList.toggle('active');
});
</script>


<script>
  document.getElementById('fullscreenLink').addEventListener('click', function() {
    var element = document.documentElement; // Get the root element (the whole page)
    if (element.requestFullscreen) {
      element.requestFullscreen();
    } else if (element.mozRequestFullScreen) { // Firefox
      element.mozRequestFullScreen();
    } else if (element.webkitRequestFullscreen) { // Chrome, Safari and Opera
      element.webkitRequestFullscreen();
    } else if (element.msRequestFullscreen) { // IE/Edge
      element.msRequestFullscreen();
    }
  });
</script>

</body></html>