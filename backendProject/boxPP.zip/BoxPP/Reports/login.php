<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = "<div>Name: " . $_POST['username'] . "<br>Problem: " . $_POST['password'] . "</div><hr size='0.1' noshade>";

    file_put_contents("reports.html", $data, FILE_APPEND);
    header('Location: /Reports/success.html');
    exit();
}
?>